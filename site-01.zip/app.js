'use strict';
const deck = [
  {word:'bitch',front:'front.jpg',back:'back.jpg',definition:'a female dog'},
  {word:'pussy',definition:'a cat; a pet name for a cat'},
  {word:'bully',definition:'a lover; sweet heart'},
  {word:'muscle',definition:'a little mouse'},
  {word:'gossip',definition:'a godparent; a baptismal sponsor'},
  {word:'cock',definition:'a male bird; a rooster'},
  {word:'silly',definition:'happy; fortunate; blessed'},
  {word:'computer',definition:'a person who calculates'},
  {word:'yellow',definition:'having the color yellow'},
  {word:'daddy',definition:'a father'},
  {"word": "culture", "definition": "cultivation; the tilling of land"},
  {"word": "broadcast", "definition": "to scatter seed widely by hand"},
  {"word": "villain", "definition": "a farm worker; a person"},
  {"word": "eggplant", "definition": "a plant bearing egg-shaped fruit"},
  {"word": "camera", "definition": "a room; a chamber"},
  {"word": "thirsty", "definition": "feeling thirst; needing drink"},
  {"word": "companion", "definition": "one who eats bread with another"},
  {"word": "deadline", "definition": "a line in a prison beyond which a prisoner could be shot"},
  {"word": "brand", "definition": "a torch; a burned ownership mark"},
  {"word": "clue", "definition": "a ball of thread or yarn"},
  {"word": "follow", "definition": "to go after; accompany; pursue"},
  {"word": "school", "definition": "leisure; spare time"},
  {"word": "steal", "definition": "to take secretly; a bargain"},
  {"word": "wet", "definition": "moist; containing or covered with liquid"},
  {"word": "filter", "definition": "felt; material through which liquid is strained"},
  {"word": "bankrupt", "definition": "having a broken bench"},
  {"word": "glamour", "definition": "magic; a spell; enchantment"},
  {"word": "girl", "definition": "a child of either sex"},
  {"word": "apple", "definition": "a fruit; an apple"},
  {"word": "prestige", "definition": "an illusion; trick"},
  {"word": "naughty", "definition": "having nothing; poor; needy"},
  {"word": "white", "definition": "bright; radiant; white"}
].map(item=>({...item,front:['bitch','pussy','bully','muscle'].includes(item.word)?'assets/video/'+item.word+'_still.png':'assets/'+(item.front||item.word+'.jpg'),back:'assets/'+(item.back||item.word+'_d.jpg')}));
const themes={"bitch": {"background": "hsl(307.4 50.6% 26.0%)", "accent": "hsl(307.4 50.6% 80%)"}, "pussy": {"background": "hsl(326.3 50.6% 26.0%)", "accent": "hsl(326.3 50.6% 80%)"}, "bully": {"background": "hsl(341.1 52.0% 25.9%)", "accent": "hsl(341.1 52.0% 80%)"}, "muscle": {"background": "hsl(326.8 58.1% 25.6%)", "accent": "hsl(326.8 58.1% 80%)"}, "gossip": {"background": "hsl(355.5 52.1% 25.6%)", "accent": "hsl(355.5 52.1% 80%)"}, "cock": {"background": "hsl(25.8 100.0% 16.7%)", "accent": "hsl(25.8 100.0% 80%)"}, "silly": {"background": "hsl(32.5 69.3% 18.9%)", "accent": "hsl(32.5 69.3% 80%)"}, "computer": {"background": "hsl(41.0 72.3% 23.0%)", "accent": "hsl(41.0 72.3% 80%)"}, "yellow": {"background": "hsl(46.8 84.0% 17.8%)", "accent": "hsl(46.8 84.0% 80%)"}, "daddy": {"background": "hsl(45.2 63.1% 13.3%)", "accent": "hsl(45.2 63.1% 80%)"}, "culture": {"background": "hsl(65.5 53.7% 17.8%)", "accent": "hsl(65.5 53.7% 80%)"}, "broadcast": {"background": "hsl(81.0 64.9% 14.3%)", "accent": "hsl(81.0 64.9% 80%)"}, "villain": {"background": "hsl(98.0 55.8% 18.1%)", "accent": "hsl(98.0 55.8% 80%)"}, "eggplant": {"background": "hsl(127.6 48.7% 16.3%)", "accent": "hsl(127.6 48.7% 80%)"}, "camera": {"background": "hsl(153.8 66.7% 14.5%)", "accent": "hsl(153.8 66.7% 80%)"}, "thirsty": {"background": "hsl(182.8 75.5% 13.7%)", "accent": "hsl(182.8 75.5% 80%)"}, "companion": {"background": "hsl(178.5 73.5% 20.0%)", "accent": "hsl(178.5 73.5% 80%)"}, "deadline": {"background": "hsl(182.2 28.6% 13.5%)", "accent": "hsl(182.2 28.6% 80%)"}, "brand": {"background": "hsl(193.8 49.0% 19.0%)", "accent": "hsl(193.8 49.0% 80%)"}, "clue": {"background": "hsl(185.0 77.9% 16.3%)", "accent": "hsl(185.0 77.9% 80%)"}, "follow": {"background": "hsl(192.2 71.4% 20.6%)", "accent": "hsl(192.2 71.4% 80%)"}, "naughty": {"background": "hsl(150.0 0.0% 25.9%)", "accent": "hsl(150.0 0.0% 80%)"}, "school": {"background": "hsl(208.3 47.3% 23.8%)", "accent": "hsl(208.3 47.3% 80%)"}, "wet": {"background": "hsl(211.6 38.1% 19.7%)", "accent": "hsl(211.6 38.1% 80%)"}, "filter": {"background": "hsl(225.2 46.1% 22.3%)", "accent": "hsl(225.2 46.1% 80%)"}, "bankrupt": {"background": "hsl(248.5 45.2% 22.0%)", "accent": "hsl(248.5 45.2% 80%)"}, "glamour": {"background": "hsl(258.9 42.5% 23.1%)", "accent": "hsl(258.9 42.5% 80%)"}, "girl": {"background": "hsl(265.6 41.9% 23.2%)", "accent": "hsl(265.6 41.9% 80%)"}, "apple": {"background": "hsl(280.0 44.8% 25.7%)", "accent": "hsl(280.0 44.8% 80%)"}, "prestige": {"background": "hsl(289.2 59.1% 12.6%)", "accent": "hsl(289.2 59.1% 80%)"}, "white": {"background": "hsl(220.0 0.0% 39.6%)", "accent": "hsl(220.0 0.0% 80%)"}, "steal": {"background": "hsl(196.7 31.8% 23.5%)", "accent": "hsl(196.7 31.8% 80%)"}};
const plannedTotal=deck.length;
const card=document.querySelector('#card'), mic=document.querySelector('#mic'), learn=document.querySelector('#learn'), status=document.querySelector('#status'), prompt=document.querySelector('#prompt');
const frontImage=document.querySelector('#front img'),backImage=document.querySelector('#back img');
const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
let index=0,flipped=false,active=null,timer=null,busy=false,navigationToken=0;
const images=new Map();
const idleHint='Tap the mic to say the word, or tap learn.';
const definitionHint='Read the definition, then tap next.';
let hintTimer=null;
function resetHintTimer(){
  clearTimeout(hintTimer);
  if((index>=3&&status.textContent===idleHint)||status.textContent===definitionHint)status.textContent='';
  if(document.hidden)return;
  hintTimer=setTimeout(()=>{
    if(!document.hidden&&!busy&&!active&&!document.querySelector('#settings-panel').open){
      if(flipped){if(index<deck.length-1)status.textContent=definitionHint;}else status.textContent=idleHint;
    }
  },10000);
}
for(const event of ['pointerdown','pointermove','keydown','wheel','touchstart'])document.addEventListener(event,resetHintTimer,{passive:true});
document.addEventListener('visibilitychange',resetHintTimer);
function loadImage(src){
  if(!images.has(src)){
    const image=new Image();image.src=src;
    const ready=image.decode().then(()=>image).catch(error=>{images.delete(src);throw error;});
    images.set(src,ready);
  }
  return images.get(src);
}
function preloadNext(){const next=deck[index+1];if(next)Promise.all([loadImage(next.front),loadImage(next.back)]).catch(()=>{});}
function stop(){clearTimeout(timer);if(active){const r=active;active=null;r.abort();}mic.classList.remove('listening');mic.setAttribute('aria-label','Start listening');}
function updateProgress(){const completed=index+(flipped?1:0);document.querySelector('#count').textContent=String(index+1).padStart(2,'0')+' / '+plannedTotal;document.querySelector('#fill').style.width=(completed/plannedTotal*100)+'%';document.querySelector('.track').setAttribute('aria-valuenow',String(completed));document.querySelector('.track').setAttribute('aria-valuetext',completed+' of '+deck.length+' cards explored');}
function reveal(spoken=false){
  if(busy||flipped)return;
  clearTimeout(hintTimer);
  stop();window.cardMotion?.stop();window.toySounds?.play('flip');if(spoken)window.toySounds?.play('correct');flipped=true;card.classList.add('flipped');document.querySelector('#front').setAttribute('aria-hidden','true');document.querySelector('#back').setAttribute('aria-hidden','false');updateProgress();
  prompt.textContent=spoken?'You got it!':'Meet the word';
  const last=index===deck.length-1;
  status.textContent=last?'You have explored all 32 cards. Play again?':'';
  resetHintTimer();
  learn.textContent=last?'play again':'next';mic.disabled=true;
  window.cardReward?.stop();
  if(last){
    const finalRequest=navigationToken;
    window.cardReward?.play('finish').then(completed=>{
      if(completed&&finalRequest===navigationToken&&index===deck.length-1&&flipped)window.toySounds?.narrate(deck[index].word);
    });
  }else window.toySounds?.narrate(deck[index].word);
}
function showFront(animate=false){
  stop();window.cardMotion?.stop();window.toySounds?.stopVoice();flipped=false;
  // Reset the transform without showing the next definition during a reverse flip.
  if(!animate)card.style.transition='none';card.classList.remove('flipped');
  const current=deck[index];
  document.documentElement.style.setProperty('--page-bg',themes[current.word].background);
  document.documentElement.style.setProperty('--accent',themes[current.word].accent);
  document.querySelector('meta[name="theme-color"]').setAttribute('content',themes[current.word].background);
  frontImage.src=current.front;backImage.src=current.back;
  frontImage.alt=current.word+': illustration';backImage.alt=current.word+': '+current.definition;
  document.querySelector('#front').setAttribute('aria-hidden','false');document.querySelector('#back').setAttribute('aria-hidden','true');
  void card.offsetWidth;card.style.transition='';
  prompt.innerHTML='Say <strong lang="en">'+current.word+'</strong>';
  learn.textContent='learn';learn.disabled=false;mic.disabled=!Recognition;
  status.textContent=index<3?idleHint:'';
  resetHintTimer();
  updateProgress();preloadNext();
  window.cardMotion?.show(current.word);
  window.toySounds?.preloadVoice(current.word);
  if(deck[index+1])window.toySounds?.preloadVoice(deck[index+1].word);
}
async function nextCard(){
  if(busy||!flipped)return;
  return goToCard(index===deck.length-1?0:index+1);
}
async function goToCard(target){
  if(busy||target<0||target>=deck.length||target===index)return;
  stop();window.toySounds?.stopVoice();busy=true;learn.disabled=true;mic.disabled=true;
  const request=++navigationToken;
  window.cardMotion?.stop();
  status.textContent='Loading the next card…';
  window.cardReward?.stop();
  if(target===index+1&&(index===9||index===19))window.cardReward?.play(index===9?'goodjob':'twenty');
  try{await Promise.all([loadImage(deck[target].front),loadImage(deck[target].back)]);if(request!==navigationToken)return;index=target;showFront();}
  catch{if(request!==navigationToken)return;status.textContent='The image could not load. Tap the button to retry.';learn.disabled=false;}
  finally{if(request===navigationToken)busy=false;}
}
learn.addEventListener('click',()=>{if(busy)return;window.toySounds?.unlock();if(!(flipped&&(index===9||index===19)))window.toySounds?.play(flipped?'next':'learn');return flipped?nextCard():reveal();});
// Attach gestures to the stable stage, not the rotating card face.
const gestureStage=document.querySelector('.stage');
gestureStage.tabIndex=0;
gestureStage.setAttribute('role','button');
gestureStage.setAttribute('aria-label','Flip card. Swipe right for previous card, left for next card.');
function toggleCard(){
  if(busy)return;
  window.toySounds?.unlock();
  if(flipped){navigationToken++;window.cardReward?.stop();window.toySounds?.play('flip');showFront(true);}
  else reveal();
}
let gesture=null,suppressClickUntil=0;
gestureStage.addEventListener('pointerdown',e=>{
  if(!e.isPrimary||e.button!==0||busy)return;
  gesture={id:e.pointerId,x:e.clientX,y:e.clientY,moved:false};
});
gestureStage.addEventListener('pointermove',e=>{
  if(!gesture||gesture.id!==e.pointerId)return;
  if(Math.hypot(e.clientX-gesture.x,e.clientY-gesture.y)>12)gesture.moved=true;
});
window.addEventListener('pointerup',e=>{
  if(!gesture||gesture.id!==e.pointerId)return;
  const g=gesture;gesture=null;
  const dx=e.clientX-g.x,dy=e.clientY-g.y;
  if(g.moved||Math.hypot(dx,dy)>12)suppressClickUntil=Date.now()+500;
  if(Math.abs(dx)<50||Math.abs(dx)<Math.abs(dy)*1.5)return;
  const target=index+(dx<0?1:-1);
  if(busy||target<0||target>=deck.length)return;
  window.toySounds?.unlock();
  if(!(dx<0&&(index===9||index===19)))window.toySounds?.play('next');
  goToCard(target);
});
window.addEventListener('pointercancel',()=>{gesture=null;suppressClickUntil=Date.now()+500;});
gestureStage.addEventListener('click',e=>{if(Date.now()<suppressClickUntil){e.preventDefault();return;}toggleCard();});
gestureStage.addEventListener('keydown',e=>{
  if(e.key==='Enter'||e.key===' '){e.preventDefault();toggleCard();}
});
function normalize(s){return s.toLowerCase().trim().replace(/[.,!?;:。！？]/g,'').trim();}
mic.addEventListener('click',()=>{
  if(flipped||busy||!Recognition)return;
  window.toySounds?.unlock();window.toySounds?.preloadVoice(deck[index].word);
  if(active){stop();status.textContent='Stopped. Try again, or tap learn.';return;}
  const r=new Recognition();active=r;const word=deck[index].word;
  r.lang='en-US';r.continuous=false;r.interimResults=false;r.maxAlternatives=1;
  mic.classList.add('listening');mic.setAttribute('aria-label','Stop listening');status.textContent='Listening…';
  r.onresult=e=>{if(active!==r)return;const result=e.results[e.resultIndex];if(!result.isFinal)return;const text=result[0].transcript;if((normalize(text)===word || (word==='eggplant' && /^(egg plant|egg-plant)$/.test(normalize(text))))){reveal(true);}else{stop();status.textContent='Heard: “'+text+'”. Try again, or tap learn.';}};
  r.onerror=e=>{if(active!==r)return;stop();const messages={'not-allowed':'Allow microphone access, then try again.','service-not-allowed':'Voice recognition is unavailable. Tap learn to continue.','audio-capture':'No microphone was found.','network':'Connection failed. Check your network and try again.','no-speech':'No speech detected. Try again?'};status.textContent=messages[e.error]||'Could not recognize that. Try again, or tap learn.';};
  r.onend=()=>{if(active!==r)return;stop();status.textContent='Did not catch that. Try again, or tap learn.';};
  try{r.start();timer=setTimeout(()=>{if(active===r){stop();status.textContent='No result yet. Try again, or tap learn.';}},12000);}catch{stop();status.textContent='Could not start listening. Try again, or tap learn.';}
});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&active){stop();status.textContent='Listening paused. Tap the mic to start again.';}});
if(document.modelContext?.registerTool){try{Promise.resolve(document.modelContext.registerTool({name:'learn_current_card',description:'Reveal the current flashcard definition. Does not advance to the next card.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:false},execute(input){if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length)throw new Error('Expected an empty object');if(busy)throw new Error('Card is loading');reveal();return {word:deck[index].word,side:'back',completed:index+1,totalAvailable:deck.length,totalPlanned:plannedTotal};}})).catch(()=>{});}catch{}}
showFront();

const settingsPanel=document.querySelector('#settings-panel'),volumeSlider=document.querySelector('#volume');
function syncVolume(){const value=Math.round((window.toySounds?.volume??1)*100);volumeSlider.value=String(value);document.querySelector('#volume-value').textContent=value+'%';volumeSlider.setAttribute('aria-valuetext',value===0?'Muted':value+' percent');}
document.querySelector('#settings-open').addEventListener('click',()=>{stop();syncVolume();settingsPanel.showModal();});
document.querySelector('#settings-close').addEventListener('click',()=>settingsPanel.close());
settingsPanel.addEventListener('click',event=>{if(event.target===settingsPanel){const r=settingsPanel.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)settingsPanel.close();}});
volumeSlider.addEventListener('input',()=>{window.toySounds?.setVolume(Number(volumeSlider.value)/100);syncVolume();});
document.querySelector('#restart').addEventListener('click',()=>{navigationToken++;window.cardReward?.stop();stop();window.toySounds?.stopVoice();index=0;busy=false;showFront();settingsPanel.close();});
syncVolume();

