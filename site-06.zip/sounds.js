'use strict';
// Tiny, slightly wonky toy instruments, synthesized locally without downloads.
window.toySounds=(()=>{
 let context,master,outputGain,level=1,enabled=true;
 try{const saved=localStorage.getItem('toy-volume');level=saved===null?(localStorage.getItem('toy-sound')==='off'?0:1):Number(saved);if(!Number.isFinite(level))level=1;level=Math.max(0,Math.min(1,level));enabled=level>0;}catch{}
 function unlock(){
  try{
   const Audio=window.AudioContext||window.webkitAudioContext;
   if(!Audio)return;
   if(!context){context=new Audio();master=context.createGain();master.gain.value=.34;outputGain=context.createGain();outputGain.gain.value=level;master.connect(outputGain);outputGain.connect(context.destination);}
   if(context.state==='suspended')context.resume().catch(()=>{});
  }catch{}
 }
 function tone(freq,start,duration,volume=.3,bend=1){
  const osc=context.createOscillator(),gain=context.createGain();
  osc.type='sine';osc.frequency.setValueAtTime(freq,start);osc.frequency.exponentialRampToValueAtTime(freq*bend,start+duration);
  gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(volume,start+.008);gain.gain.exponentialRampToValueAtTime(.0001,start+duration);
  osc.connect(gain);gain.connect(master);osc.start(start);osc.stop(start+duration+.02);
  osc.onended=()=>{osc.disconnect();gain.disconnect();};
 }
 function paper(start){
  const duration=.24,buffer=context.createBuffer(1,Math.ceil(context.sampleRate*duration),context.sampleRate),data=buffer.getChannelData(0);
  for(let i=0;i<data.length;i++){const t=i/data.length;data[i]=(Math.random()*2-1)*Math.sin(Math.PI*t)**2*(.65+.35*Math.sin(t*95));}
  const src=context.createBufferSource(),filter=context.createBiquadFilter(),gain=context.createGain();
  src.buffer=buffer;filter.type='bandpass';filter.Q.value=.7;filter.frequency.setValueAtTime(1800,start);filter.frequency.exponentialRampToValueAtTime(650,start+duration);gain.gain.value=.16;
  src.connect(filter);filter.connect(gain);gain.connect(master);src.start(start);src.onended=()=>{src.disconnect();filter.disconnect();gain.disconnect();};
 }
 function play(kind){
  if(!enabled)return;
  unlock();if(!context)return;
  if(context.state==='suspended'){context.resume().then(()=>{if(context.state==='running')play(kind);}).catch(()=>{});return;}
  if(context.state!=='running')return;
  try{
   const t=context.currentTime+.008;
   if(kind==='flip')paper(t);
   if(kind==='learn'){tone(523,t,.16,.3,1.025);tone(659,t+.085,.19,.28,.99);tone(805,t+.17,.27,.24,1.035);}
   if(kind==='correct'){tone(1046,t,.38,.32,1.006);tone(1588,t+.035,.3,.12,.99);tone(2093,t+.075,.22,.07);}
   if(kind==='next'){tone(370,t,.13,.28,1.5);tone(740,t+.055,.17,.18,.91);}
  }catch{}
 }
 // Original artist recordings: no speech synthesis, pitch shift, or speed change.
 let narrationToken=0,narration=null;
 const voiceFiles=new Map();
 function preloadVoice(word){
  if(!voiceFiles.has(word))voiceFiles.set(word,fetch('assets/voice/'+word+'.m4a?v=2').then(r=>{
   if(!r.ok)throw new Error('Recording unavailable');return r.arrayBuffer();
  }).catch(()=>{voiceFiles.delete(word);return null;}));
  return voiceFiles.get(word);
 }
 function stopVoice(){
  narrationToken++;
  if(narration){try{narration.stop();}catch{}narration.disconnect();narration=null;}
 }
 async function narrate(word,onComplete){
  stopVoice();if(!enabled){setTimeout(()=>onComplete?.(),600);return;}unlock();const token=narrationToken;
  try{
   if(!context)throw new Error('Audio unsupported');
   await context.resume();
   const bytes=await preloadVoice(word);
   if(token!==narrationToken||!enabled||document.hidden)return;
   if(!bytes)throw new Error('Recording unavailable');
   const buffer=await context.decodeAudioData(bytes.slice(0));
   if(token!==narrationToken||!enabled||document.hidden)return;
   const source=context.createBufferSource(),volume=context.createGain();
   source.buffer=buffer;source.playbackRate.value=1;volume.gain.value=.9;
   source.connect(volume);volume.connect(outputGain);narration=source;
   source.onended=()=>{source.disconnect();volume.disconnect();if(narration===source)narration=null;if(token===narrationToken)onComplete?.();};
   source.start(context.currentTime+.28);
  }catch{
   if(token===narrationToken&&enabled&&!document.hidden){
    const status=document.querySelector('#status');
    if(status)status.textContent='The recording could not play. Check your connection and try again.';onComplete?.();
   }
  }
 }
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stopVoice();});
 function setVolume(value){
  if(!Number.isFinite(Number(value)))return;
  level=Math.max(0,Math.min(1,Number(value)));enabled=level>0;unlock();
  if(outputGain)outputGain.gain.setValueAtTime(level,context.currentTime);
  try{localStorage.setItem('toy-volume',String(level));}catch{}
 }
 return{unlock,play,setVolume,narrate,stopVoice,preloadVoice,get volume(){return level;},get enabled(){return enabled;}};
})();
