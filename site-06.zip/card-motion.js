'use strict';
(() => {
  const video=document.querySelector('#front-video');
  const image=document.querySelector('#front img');
  const words=new Set(['bitch','pussy','bully','muscle','cock','computer','daddy','yellow','broadcast','villain','companion','deadline','thirsty','follow','wet','prestige','glamour','girl','naughty']);
  let generation=0,timer=null,current=null;
  function cancel(){
    generation++;clearTimeout(timer);timer=null;
    video.onended=null;video.onplaying=null;video.onerror=null;
    video.onloadeddata=null;video.onseeked=null;
    video.pause();video.hidden=true;
  }
  function stop(){current=null;cancel();image.hidden=false;video.removeAttribute('src');video.load();}
  function start(){
    cancel();
    if(!current||document.hidden)return;
    const token=generation;
    image.hidden=true;video.hidden=false;video.muted=true;
    const valid=()=>token===generation&&!document.hidden&&current!==null;
    function play(){
      if(!valid())return;
      const attempt=video.play();
      if(attempt)attempt.catch(()=>{});
    }
    // loadeddata means the paused video has its actual first frame available.
    video.onloadeddata=()=>{if(valid()){video.onloadeddata=null;timer=setTimeout(play,500);}};
    video.onended=()=>{
      if(!valid())return;
      video.onseeked=()=>{if(valid()){video.onseeked=null;timer=setTimeout(play,4000);}};
      video.currentTime=0;
    };
    video.onerror=()=>{if(valid())clearTimeout(timer);};
    video.src='assets/video/'+current+'_v.mp4';video.load();
  }
  function show(word){stop();if(words.has(word)){current=word;start();}}
  document.addEventListener('visibilitychange',()=>{if(document.hidden)cancel();else if(current)start();});
  window.cardMotion={show,stop};
})();
