"use strict";
window.cardReward=(()=>{
 const sources={goodjob:'assets/video/goodjob-voice.m4a',twenty:'assets/video/twenty.m4a',finish:'assets/video/finish.m4a'};
 const clips=Object.fromEntries(Object.entries(sources).map(([key,src])=>{const audio=new Audio(src);audio.preload='auto';return[key,audio];}));
 let active=null,pending=null;
 function stop(){if(active){active.onended=null;active.onerror=null;active.pause();active.currentTime=0;active=null;}if(pending){const done=pending;pending=null;done(false);}}
 function play(kind='goodjob'){
  stop();const audio=clips[kind];if(!audio)return Promise.resolve(false);active=audio;audio.volume=window.toySounds?.volume??1;
  return new Promise(resolve=>{pending=resolve;const finish=()=>{if(active!==audio)return;active=null;pending=null;resolve(true);};audio.onended=finish;audio.onerror=finish;audio.play().catch(finish);});
 }
 document.querySelector('#volume').addEventListener('input',e=>{if(active)active.volume=Number(e.target.value)/100;});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
 return{play,stop};
})();
